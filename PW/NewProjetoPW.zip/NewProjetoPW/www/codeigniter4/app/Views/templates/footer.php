</article>
</section>
<footer class="jumbotron text-center bg-primary text-white" style="height: 100px;">
    <h3>Rodape do nosso site.</h3>
    <a class="link-light" href="<?=base_url('admin')?>">Area Administrativa</a>
</footer>    
</body>
</html>