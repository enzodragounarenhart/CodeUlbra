</article>
</section>
<footer class="jumbotron text-center bg-secondary text-white" style="height: 100px;">
    <h3>Rodape do nosso site.</h3>
    <a class="link-light" href="<?=base_url('home')?>">Area Publica</a>
</footer>    
</body>
</html>