<h1>Lista de Clientes</h1>
<table class="table">
    <tr>
        <th>Codigo</th>
        <th>Nome</th>
        <th>Email</th>
        <th>Endereco</th>
        <th>Acoes</th>
    </tr>

<?php

foreach($clients as $client){
?>
    <tr>
        <td><?=$client["idClient"]?></td>
        <td><?=$client["name"]?></td>
        <td><?=$client["phone"]?></td>
        <td><?=$client["email"]?></td>
        <td><a href="<?=base_url("client/{$client['idClient']}")?>">Detalhes</a></td>
    </tr>
<?php
}
?>
</table>