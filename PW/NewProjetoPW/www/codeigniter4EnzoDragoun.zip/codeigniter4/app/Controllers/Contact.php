<?php

namespace App\Controllers;

use App\Models\ContactModel;

class Contact extends BaseController{

    public function listContacts()
    {
        $contact = new ContactModel();
        $contact -> listContacts();

        $data = ['contacts' => $contact -> listContacts()];

        echo view('templates/header');
        echo view('pages/listContacts', $data);
        echo view('templates/footer');
    }

}
?>