<?php

namespace App\Controllers;

use App\Models\ClientModel;

class Client extends BaseController{

    public function listClients()
    {
        $client = new ClientModel();
        $client -> listClients();

        $data = ['clients' => $client -> listClients()];

        echo view('templates/header');
        echo view('client/listClients', $data);
        echo view('templates/footer');
    }

}
?>